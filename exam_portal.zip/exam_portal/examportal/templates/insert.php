<?php

$fav_language=$_POST['fav_language'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];

?>