from django.conf.urls import url
from . import views
from django.urls import path, include
from django.contrib import admin
from django.views.generic.base import TemplateView



urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('main.urls')),
    path('prof/', include('prof.urls')),
    path('student/', include('student.urls')),
]
